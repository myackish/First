<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
   <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">  -->
	<title>Главная страница</title>
	<link rel="stylesheet" href="css/mystyle.css">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Merriweather|Oswald|Roboto+Condensed" rel="stylesheet">
	

	<link rel="stylesheet" type="text/css" href="css/demo.css" />
   <link rel="stylesheet" type="text/css" href="css/style.css" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Playfair+Display:400italic' rel='stylesheet' type='text/css' />
	<noscript>
		<link rel="stylesheet" type="text/css" href="css/noscript.css" />
	</noscript>
</head>




<body>

	<div id="header">
		<ul>
			<li><a href="#">Главная</a></li>
			<li><a href="#">Работы</a></li>
			<li><a href="#">Контакты</a></li>
		</ul>
	</div>
	
		<div id="content">
		
			<div class="wrapper col-lg-12 col-md-12 ">
                <div id="ei-slider" class="ei-slider">
                    <ul class="ei-slider-large">
						<li>
                            <img src="images/large/6.jpg" alt="image06"/>
                            <div class="ei-title">
                                <h2>Первый</h2>
                                <h3>Слайд</h3>
                            </div>
                        </li>
                        <li>
                            <img src="images/large/1.jpg" alt="image01" />
                            <div class="ei-title">
                                <h2>Второй</h2>
                                <h3>Слайд</h3>
                            </div>
                        </li>
                        <li>
                            <img src="images/large/2.jpg" alt="image02" />
                            <div class="ei-title">
                                <h2>Третий</h2>
                                <h3>Слайд</h3>
                            </div>
                        </li>
                        <li>
                            <img src="images/large/3.jpg" alt="image03"/>
                            <div class="ei-title">
                                <h2>Четвертый</h2>
                                <h3>Слайд</h3>
                            </div>
                        </li>

                    </ul><!-- ei-slider-large -->
                    <ul class="ei-slider-thumbs">
                        <li class="ei-slider-element">Current</li>
						<li><a href="#">Slide 6</a><img src="images/thumbs/6.jpg" alt="thumb06" /></li>
                        <li><a href="#">Slide 1</a><img src="images/thumbs/1.jpg" alt="thumb01" /></li>
                        <li><a href="#">Slide 2</a><img src="images/thumbs/2.jpg" alt="thumb02" /></li>
                        <li><a href="#">Slide 3</a><img src="images/thumbs/3.jpg" alt="thumb03" /></li>
                    </ul><!-- ei-slider-thumbs -->
                </div><!-- ei-slider -->
            </div><!-- wrapper -->

		</div>

		
		
		<div id="row" class="col-md-0">
			<div id="image" class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
			<p id="comments" class="col-lg-8 col-md-8 col-sm-8 col-xs-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>

		<div id="row">
			<div id="image" class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
			<p id="comments" class="col-lg-8 col-md-8 col-sm-8 col-xs-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>

	</div>


	<div id="footer">
		
	</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.eislideshow.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript">
            $(function() {
                $('#ei-slider').eislideshow({
					animation			: 'center',
					autoplay			: true,
					slideshow_interval	: 3000,
					titlesFactor		: 0
                });
            });
        </script>
</body>



	
	<script src="main.js">	</script>
</html>